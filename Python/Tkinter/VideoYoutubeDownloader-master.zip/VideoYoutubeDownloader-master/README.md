# VideoYoutubeDownloader
- This App is going to allow you to download Youtube Videos from your desktop. Gone are the days
where you have to look up 100 website to just download a video.
- To use this tkinter app all you need to do is this:
1) Run main.py.
2) Add any youtube url.
3) Add the path. This is, where you want the video to be located in your computer. For example,  /Users/mohammad/PycharmProjects/VideoYoutubeDownloader
Run the command "pwd" in the terminal to get the path faster.
4) Chose the quality that you want.
5) press "Download"
