// alert("Hello");
    
document.write("Hello");